# arguments and keywords
# *args **kwargs
def summate(*args):
    print(args) # a tuple is provided
    return sum(args)

print(summate(-1, -2, -3, -4, 4, 3, 2, 1))

def super_func(*args, **kwargs):
    print(kwargs) # kwargs is a dicitonary
    total = 0
    for items in kwargs.values():
        total += items
    return sum(args) + total

print(super_func(1,2,3,4,5, a = 1, b = 2, c = 3, d = 4))

# Rule: parameters, *args, default named parameters, **kwargs
