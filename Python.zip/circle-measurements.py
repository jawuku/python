# circle measurements
# area = pi * r^2
# circ = 2 * pi * r
import math

radius = float(input("Enter radius of circle: "))

area   = math.pi * (radius ** 2)

circum = math.pi * 2 * radius

print(f"Area of the circle is {area}")
print(f"Circumference of the circle is {circum}")