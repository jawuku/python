# clean code

# 1) naive code
def is_even1(num):
    if num % 2 == 0:
        return True
    elif num % 2 == 1:
        return False

print(34, is_even1(34))
print(35, is_even1(35))

# 2) some optimisation
def is_even2(num):
    if num % 2 == 0:
        return True
    return False

print(11, is_even2(11))
print(12, is_even2(12))

# 3) more optimisation
def is_even3(num):
    return num % 2 == 0 # expression evaluates to True or False

print(62, is_even3(62))
print(63, is_even3(63))
