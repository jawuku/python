old_enough = False
licensed = True

# if keyword
if old_enough:
    print("you are old enough to drive")

# if .. else
if not old_enough:
    print("Wait until you're 18 until you can drive.")
else:
    print("Welcome to driving!")

# elif means else if
if old_enough:
    print("You are old enough to drive")
elif licensed:
    print("You have a license")
else:
    print("You are not of age, nor are you licensed.")

# combining conditions
if old_enough and licensed:
    print("You are old enough entitled to drive")
else:
    print("you cannot drive!")
