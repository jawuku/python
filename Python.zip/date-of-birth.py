# Lists and Tuples
# create a progream to ask user for birthday in DD-MM-YYYY format
# Output "You were born in {month}"
dob = input("Enter your date of birth in the format DD-MM-YYYY : ")

month_slice = int(dob[3:5])

month_tuple = ("", "January", "February", "March", "April", "May",
               "June", "July", "August", "September", "October",
               "November", "December")

born_in = month_tuple[month_slice]

print(f"You were born in {born_in}.")

# Create a program with a predifined list of people.
# Ask the user for their name, add it to the end of list
# Print updated list
employee_list = ["Sandra Atkins", "Herbert Bagshot", "Tina Curry",
                 "David Drayton", "Fiona Eggington"]

new_employee = input("Welcome to Underwood Industries.\nWhat is your name? ")

employee_list.append(new_employee)

print(employee_list)