# user profile

user = dict(username  = 'Legolas',
            weapons   = ['bow', 'arrows', 'sword'],
            clan      = 'Wood Elves',
            is_active = True)

# display all keys in an iteration
for i in user.keys():
    print(i)

# add new weapon to user
user['weapons'].append('Orc/goblin poison')

print(user)

# add is_banned key
user.update({'is_banned': False})

print(user)

# set banned to false
user.update({'is_banned' : True})
print(user)

# create new user
user2 = user.copy()

user2.update({'username' : 'Galadriel', 'age' : 'ageless beauty'})
print(user2)
