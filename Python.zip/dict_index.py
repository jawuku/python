my_dict_list = [
    {
        'a' : [1,2,3],
        'b' : 'hello',
        'c' : True
        },
    {
        'a' : [4,5,6],
        'b' : 'goodbye',
        'c' : False
        }
    ]

# get the number 3 in first list
print(my_dict_list[0]['a'][2])

# this is not true?
print(my_dict_list[1]['c'])