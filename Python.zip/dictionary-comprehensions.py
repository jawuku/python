# Dictionary comprehensions - create a key:value pair, value acted upon
# square each value in turn
simpledict = dict(a=1, b=2, c=3, d=4)
mydict = {key:value**2 for key,value in simpledict.items()}

print(mydict)

# only add square to dictionary if number is odd
odd_dict = {key:value**2 for key,value in simpledict.items()
            if value % 2 == 1}

print(odd_dict)

# dictionary comprehension from list
# where key is number in list, value is number * 2
dict2 = {num:num*2 for num in [1,2,3,4,5]}
print(dict2)