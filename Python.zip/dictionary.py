# Dictionary methods -  create with curly brackets
user = {
    'basket': [1,2,3],
    'greet' : "Hello",
    'age'   : 30
    }

# another way of creating dictionary
# string keys are not enclosed in quotes
record = dict(Name = 'John Atkins', Age = 30, City = 'Manchester')
print(record)

# retrieve value
print(user['age']) # 30

# user['city'] does not exist in dictionary, so produces an error

# non-error method of searching for a non-existent entry - get
# gives a None value
print(user.get('city'))

# specify default value for non-existent key/values 
print(user.get('city', 'London')) # returns 'London'

# check if key exists in dictionary
print('greet' in user) # True

# another way to check
print('size' in user.keys()) # False

# check value exists
print(30 in user.values()) # True

# items method takes all the keys and values together
print(user.items())

# copys a dictionary
user2 = user.copy()
user3 = user.copy()
print(user)
print(user2)

# clears dictionary
user.clear()
print(user) # empty
print(user2) # copy unchanged

# remove a specifiied key from dictionary, returns the value
print(user2.pop('greet'))
print(user2)

# pops an unspecified item (often the last item)
print(user3.popitem())
print(user3)

# updates a value in an existing key
user3.update({'greet': "Guten Tag"})
print(user3)

# use update to add new key/value pair(s)
user3.update({'age' : 46, 'occupation' : 'Aspirant ML Engineer'})
print(user3)
