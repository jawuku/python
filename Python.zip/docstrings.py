# docstrings
def sqr(x):
    '''
Returns the product of the number `x` with itself
'''
    return x * x

print(sqr(7))

# display docstring
help(sqr)

# another way to display docstring
print(sqr.__doc__)
