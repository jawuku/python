# enumerate() - to generate index for each character
for i, char in enumerate("Hello, World!"):
    print(i,char)

for i,char in enumerate([1,2,3]):
    print(i,char)

for i,char in enumerate((1,2,3)):
    print(i,char)

print()
# create a script to generate an index for a given item in a sequence
# print indexes for each soft sign 'ь'
un_human_rights_ukr = """Стаття 1. 
Всі люди народжуються вільними і рівними 
у своїй гідності та правах. Вони наділені розумом і совістю і повинні діяти у відношенні 
один до одного в дусі братерства."""

for i, char in enumerate(un_human_rights_ukr):
    if char == 'ь':
        print(f"{char} (soft sign) is at index {i}")
    else:
        print(i,char)

