# functions
def say_hello():
    print("Hello!")

say_hello()

def showtree():
    picture = [
        [0,0,0,1,0,0,0],
        [0,0,1,1,1,0,0],
        [0,1,1,1,1,1,0],
        [1,1,1,1,1,1,1],
        [0,0,0,1,0,0,0],
        [0,0,0,1,0,0,0]
        ]

    list_count = len(picture)

    dot_matrix = ""

    for row in picture:
        for digit in row:
            if digit == 0:
                dot_matrix += " "
            else:
                dot_matrix += "*"
        dot_matrix += "\n"

    print(dot_matrix)

showtree()