# For loops- loop over an iterable (range, collection, sequence)
# e.g. for strings
for item in "Learning python":
    print(item, end = " ")

print()

# also with lists
for number in [1,2,3,4,5,6,7,8,9]:
    print(number, end = "")

print()

# tuples,
for n in (1,2,3,4,5,6,7,8,9):
    print(n, end = ".")

print()

# sets,
for n in {1,2,3,4,5,6,7,8,9}:
    print(n, end = "*")

print()
# also works with ranges and dictionaries

# nested for loops
for a in ['a', 'b', 'c']:
    for b in [1,2,3,4,5]:
        print(f"{a}{b}")
