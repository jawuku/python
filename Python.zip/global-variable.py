# global variables
total = 0

def count():
    global total
    total += 1
    return total

count()
count()
print(count())

# better to do dependency injection
total = 0

def count2(total):
    total += 1
    return total

print(count2(count2(count2(total))))