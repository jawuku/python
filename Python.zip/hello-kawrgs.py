# keyword arguments
def hello(name = "World"):
    print(f"Hello, {name}!")
    #print("Hello, " + name + "!")
    #print("Hello, {}!".format(name))
    #print("Hello, %s!" % (name))
hello()
hello("Python")
