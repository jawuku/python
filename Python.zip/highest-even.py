def is_odd(n):
    return n % 2 == 1

def highest_even(li):
    
    for i in li:
        if is_odd(i):
            li.remove(i)
    #li.sort()
    #li.reverse()
    #return li[0]
    return max(li) # tutor's way

print(highest_even([1,5,8,4,1,98,428,5,7,4,21,12,-345]))

# result = 428

# Clojure equivalent:
# 
# (defn highest-even [collection]
#   (apply max (filter (fn [x] (even? x)) collection)))