# iterables - a collection that can be iterated over
# e.g. string, list, dictionary, tuple, set, range
# they can be iterated - element-wise looping in a collection

# e.g. for dictionary
user = {
    'name'      : "Gollum",
    'age'       :  70,
    'eats_fish' : True,
    'is_pretty' : False}

# print each item (key/value pair)
for item in user.items():
    print(item)

print()
# print each key
for attribute in user.keys():
    print(attribute)

print()
# print each value
for nums in user.values():
    print(nums)

# print key value separately outside a tuple
for key, value in user.items():
    print(f"{key}\t{value}")
