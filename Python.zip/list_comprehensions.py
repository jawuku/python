# comprehensions - on lists, sets, dictionaries
#  a way of making or appending collections without looping
# conventional method
Begrüßung = []

for char in 'Guten Tag':
    Begrüßung.append(char)

print(Begrüßung)

# comprehension method
# generated_list = [parameter for parameter in iterable (optional conditional)]
mylist = [char for char in "Guten Tag"]

print(mylist)

#generate list of numbers from 0 to 99
# conventional way
mylist2 = list(range(100)) 

print(mylist2)

# comprehension way
ml2 = [number for number in range(100)]

# even numbers on list from 0 to 99
#def is_even(n):
#    return n % 2 == 0
# even_nums = [num for num in filter(is_even, range(100))]
even_nums = [n for n in filter(lambda x: x % 2 == 0, range(100))]

print(even_nums)

# even numbers from 0 **2 to 99 ** 2
ml3 = [num ** 2 for num in filter(lambda x: x % 2 ==0, range(100))]

# alternative way
ml4 =[num ** 2 for num in range(100) if num % 2 == 0]

print(ml3); print(ml4)
