basket = ["Banana", "Apples", "Oranges", "Blueberries"]
print(basket)

# remove banana
basket.remove("Banana")
print(basket)

# remove blueberries
basket.remove("Blueberries")
print(basket)

# add Kiwi to end of list
basket.append("Kiwis")
print(basket)

# add Apples to the beginning
basket.insert(0, "Apples")
print(basket)

# count how many apples in the basket
apple_count = basket.count("Apples")
print(f"{apple_count} apples in the basket")

# empty basket
basket.clear()
print(basket)
