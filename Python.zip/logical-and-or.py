# "Short-Circuiting"
# and evaluates to true when all conditions are true
is_friend = False
is_user = True

if is_friend and is_user:
    print("Both conditions satisfied")

# or evaluates to true when even only one condition is true
if is_friend or is_user:
    print("Either condition satisfied")

# logical operators
# >  greater than
# <  less than
# == equal to
# >= greater than or equal to
# != 
print(4 > 5) # False

print(4 < 5) # True

print(4 == 5) # False

print("Hello" == "Hello") # True

print('b' > 'a') # True (ASCII/Unicode/alphabetical order)

print(1 < 2 < 3 < 4) # True for chained expressions

print(2 >= 0) # True

print(3 <= -1) # False

print("Hi" != "Bye") # True