# try amending two variables between True and False
is_magician = True
is_expert = True

# check if player is both magician and expert
if is_magician and is_expert:
    print("You are a master magician.")

# check if magician but not expert
if is_magician and not is_expert:
    print("Well, at least you're getting there.\nKeep at your training.")

# check if not a magician
if not is_magician:
    print("You need to start magic training.")
