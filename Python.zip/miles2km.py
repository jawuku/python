# Miles to Km converter

# 2.54cm in an inch
inches = 2.54

feet = inches * 12

statute_miles = feet * 5280

km = statute_miles / 100 / 1000

print(km)

km2miles = 1 / km

distance = float(input("How many kilometres? "))

converted_miles = distance * km2miles

print(f"{distance} km = {converted_miles} miles")
