## age

birth_year = int(input("In which year were you born? "))

age = 2021 - birth_year

print(f"You must be around {age} years old.")

## password checker
user = input("Enter your username: ")
passwd = input("and enter your password: ")	

length = len(passwd)
stars = '*' * length

print(f"{user}, your password {stars} is {length} characters long.")