# return functions
def add(num1, num2):
    def another_function(n1, n2):
        return n1 + n2
    return another_function(num1, num2)

total = add(10, 20)
print(total)

# crazy nested functions
# basically, return the inner function using the parameters of the next outer function
def multiply(a ,b):
    def m2(c, d):
        def m3(e, f):
            def m4(g, h):
                return g * h
            return m4(e ,f)
        return m3(c, d)
    return m2(a, b)

total2 = multiply(4,8)
print(total2)
