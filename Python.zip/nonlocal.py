# nonlocal variables
# refers to parent variable that is not global
# but is outside the scope of the function
def outer():
    x = "local"
    def inner():
        nonlocal x
        x = "nonlocal"
        print("inner:", x)
    
    inner()
    print("outer:", x)
outer()

# try commenting out the 'nonlocal x' to reveal outer x as "local"