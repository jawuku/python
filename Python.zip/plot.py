import matplotlib.pyplot as plt
import numpy as np

x = np.array(range(-5,6))
y = -2 * x ** 2 - 5

plt.title("BTW, I don't run Arch :-D")
plt.ylabel('-2x^2 - 5')
plt.plot(x,y)
plt.show()
