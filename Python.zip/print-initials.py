# strings exercise
first_name  = input("What is your first name? ")
middle_name = input("And your middle name? ")
last_name   = input("Finally, what is your last name? ")

first_initial  = first_name[0]
middle_initial = middle_name[0]
last_initial   = last_name[0]

print(f"Your Initials are: {first_initial}. {middle_initial}. {last_initial}.")
