# Pure functions
# --------------
# 
# 2 rules:
#     1) given the same input(s), should always return the same outupt
#     2) does not produce any side-effects e.g. printing, variables
#        outside the scope of the function
from functools import reduce


def times2(List):
    new_list = []
    for item in List:
        new_list.append(item*2)
    return new_list

print(times2([1,2,3]))

# map, filter, zip, reduce
# four functions used in Functional programming

# map(function, iterable)
def x2(item):
    return 2 * item
print(list(map(x2, [1,2,3])))

# map works on immutable data
mylist = [10,20,30]

print(list(map(x2, mylist))) # list * 2
print(mylist) # no change

# another example - change to all capital letters
names = ["nikki", "nelly", "luke", "janey", "bill", "stefan"]
def allcaps(person):
    return person.upper()

print(list(map(allcaps, names)))
print(names)

# filter - keep only the items you want
# in this case, only odd numbers
def check_if_odd(num):
    return num % 2 == 1

random_list =[12,33,64,27,76,49,34,72,37,34]
print(list(filter(check_if_odd, random_list)))

# updated example of highest_even exercise
def is_even(num):
    return num % 2 == 0

def highest_even(collection):
    return (max(list(filter(is_even, collection))))

print(highest_even(random_list))

# zip function - zips 2 iterables together
# mylist = [10,20,30] defined above
yourlist = [1,2,3]

print(list(zip(yourlist, mylist)))
# [(1, 10), (2, 20), (3, 30)]

# example creating a dictionary from names and addresses
names = ['Toby Hudson', 'Denise Fisher', 'Aidan Marsh', 'Elisa Goodall',
         'Casey Porter', 'Annabelle Smith','John Bentley', 'Jane Price',
         'Nathaniel King', 'Nell Mangel']

addresses = ['93 Woodbridge Way', '56 Telford Street', '38 Walnut Lane',
             '123 Acacia Avenue', '136 Dudley Road', '18 Felix Lane',
             '93 Holgate Road', '135 Wallflower Crescent',
             '79 Broughton Road', '29 Rotheram Way']
address_book = dict(zip(names, addresses))

print(address_book)

# reduce
# reduce(function, sequence, initial value)
def add(acc, item):
    return acc + item

print(reduce(add, random_list, 0))

# factorial function
def multiply(a, b):
    return a * b

def factorial(n):
    data = list(range(n))
    data = list(map(lambda x: x+1, data))
    return reduce(multiply, data, 1)
