# range()
# another type of iterable object
print(range(100)) # defaults to 100 integers from 0 - 99

for number in range(100):
    print(number, end=" ")

print()
# range with start and stop values
# start through stop-1
for number in range (-5, 6): # -5 to +5 inclusive
    print(number)

print()
# start, stop, step values

print()
# step up 2 each time
for even_numbers in range(0,21,2):
    print(even_numbers)

print()
# step down 1 each time
for countdown in range(10, 0, -1):
    print(countdown)
print("Liftoff")

# change range to another collection
print(list(range(10)))
print(tuple(range(10)))
print(set(range(10)))


# iterate over 0 to 9,
# if num % 3 == 0 print range as a list
# if num % 3 == 1 print range as a tuple
# otherwise (num % 3 == 2) print as a set
rng = range(10)
for i in rng:
    if   i % 3 == 0:
        print(list(rng))
    elif i % 3 == 1:
        print(tuple(rng))
    else:
        print(set(rng))
