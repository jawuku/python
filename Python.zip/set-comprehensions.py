# Set comprehensions - similar construction to list comprehensions
# using carly braces instead of square brackets:

# split characters in string into a set of chars
myset = {char for char in "Aloha!"}

print(myset)

# set of integers from 0-99
myset2 = {num for num in range(100)}

print(myset2)

# only display the square of the even numbers from 0 to 99
myset3 = {num ** 2 for num in range(100) if num % 2 == 0}

print(myset3)