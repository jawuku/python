# Sets - unordered collection of data
myset = {1,2,3,4,5}

print(myset)

# only unique entries
myset2 = {1, 1, 4, 5, 0, 6, 3, 2, 2, 8, 7, 9, 9, 0, 5}

print(myset2)

# add element to set
myset.add(100)
print(myset)

# use set() to convert collection into a set
mylist = [1,2,3,4,5,5]

new_set = set(mylist)

print(new_set)

# access item in set
print(1 in new_set) # True

# length of set
print(len(new_set)) # 5

# convert set to list
print(list(myset))

## Set methods

# copy set
newer_set = new_set.copy()

# clear set
new_set.clear()

print(new_set)
print()

#define sets, set refresh
set1 = {1,2,3,4,5}
seta = set1.copy()
set2 = {4,5,6,7,8,9,10}
setb = set2.copy()

# difference between sets - sets left unchanged
print(set1.difference(set2)) # {1,2,3}

# discard - removes an element from a set if it is a member
set1 = seta.copy()
set1.discard(5) # discards member 5
print(set1) # now {1,2,3,4}

# difference_update - removes all elements of another set from this set
set1 = seta.copy()
set1.difference_update(set2)
print(set1) # as 4 and 5 are also in set 2,
# these are removed from set 1 so set1 = {1,2,3}

# intersection between 2 sets - sets left unchanged
set1 = seta.copy()
print(set1.intersection(set2)) # {4,5} is the intersection

# shorthand way of doing intersection - using & (and)
print(set1 & set2)

# returns True or False whether 2 sets are intersecting
print(set1.isdisjoint(set2)) # False

print({1,2,3}.isdisjoint({4,5,6})) # True, these 2 have nothing in common

# is one set a subset of another
print({1,2,3}.issubset(set1)) # True, {1,2,3} is a subset of {1,2,3,4,5}

# is one set a superset of another
print(set1.issuperset({3,4})) # True

print(set2.issuperset(set1)) # False

# union (merging of sets)
print(set1.union(set2)) # {1,2,3,4,5,6,7,8,9,10}

# shorthand way of union - using | (or)
print(set1 | set2)

