import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(0, 2*np.pi, num=60)

y = np.sin(x)

plt.title("y = sin(x)")
plt.ylabel("sin(x)")
plt.plot(x,y)
plt.show()