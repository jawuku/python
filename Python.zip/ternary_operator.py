# Ternary Operator
# short form of if .. else

# (condition_if true) if (condition) else (do_otherwise)
is_friend = False
can_message = "message allowed" if is_friend else "not allowed to message"

print(can_message)

#  equivalent of condition ? condition_if_true : condition_if_false
