# check age function
def check_age():
    age = int(input("What is your age? "))

    if age < 18:
    	print("Sorry, you are too young to drive this car. Powering off")
    elif age > 18:
    	print("Powering On. Enjoy the ride!");
    else:
        print("Congratulations on your first year of driving. Enjoy the ride!")

check_age()

# check age function taking age as a parameter
def check_age2(age = 0):
    if age <= 0:
        print("You have not specifed a valid age. Please try again.")
    elif (age > 0) and (age < 18):
        print(f"Sorry - at age {age}, you are too young to drive this car. Powering off.")
    elif age > 18:
    	print("Powering On. Enjoy the ride!")
    else:
        print("Congratulations on your first year of driving. Enjoy the ride!")

check_age2(92)

check_age2(18)

check_age2()

check_age2(15)

check_age2(-456)
