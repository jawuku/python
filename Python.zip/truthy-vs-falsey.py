# Truthy vs falsey
print(bool(True))
print(bool("hello"))
print(bool(5.5))
print(bool(5 - 3.5j))
print(bool({'a' : 1, 'b' :2}))
print(bool(0))
print(bool(""))
print(bool([]))
print(bool(False))
print(bool(None))

# All values are truthy except
# False
# None
# 0 (int)
# 0.0 (float)
# 0j (complex number)
# Decimal(0)
# Fraction(0, 1)
# empty list, dict, tuple, str, set
# empty range e.g. range(0)
# empty bytes b''
