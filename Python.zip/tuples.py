# Tuples - immutable ordered collection
# use for things you don't want to change
my_tuple = (1,2,3,4,5)

# another way
my_other_tuple = tuple(range(5))

# can access by index, like a list
print(my_tuple[1]) # 2

# does entry exist
print(5 in my_tuple) # True

# use slice of tuple to create new one
new_tuple = my_tuple[2:]
print(new_tuple) #  (3,4,5)

# destructure tuple
x,y, *z = my_tuple
print(x)
print(y)
print(z) # converts to a vector
print(type(z))

# only 2 methods
print(my_tuple.count(4)) # counts occurrence of 4

print(my_other_tuple.index(2)) # 2 is at index 2

# find length of tuple
print(len(my_other_tuple)) # 5
