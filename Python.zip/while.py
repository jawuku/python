# while loops -= iterates only when condition is true

# infinite loop

# while True:
#     print("This goes forever")

# break statement breaks out of a loop
while True:
    print("This won't go forever")
    break

# to repeat x number of times
x = 0
while x < 50:
    print(x, end = " ")
    x += 1

# can also incorporate else blocks when condition turns false
x = 0
while x < 10:
    print(x)
    x += 1
else:
    print("Finished")

# when to use for or while loops
# for loops - simple iteration over a sequence
# while loops - when uncertain of number of iterations

while True:
    number = int(input("Enter an integer between 0 and 99 "))
    if number < 55:
        print("Go higher")
    elif number > 55:
        print("Go lower")
    else:
        print("Well done, you got the right number")
        break
